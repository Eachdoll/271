# Claude Code 개발 안내

이 프로젝트는 동화공방의 실제 소스입니다. 먼저 `CLAUDE_CODE_START_HERE.md`, `README.md`, `STORY_QUALITY_INTEGRATION.md`를 읽으세요.

## 편집 위치

- **루트 `dist/`는 편집하는 프런트엔드 소스입니다.** 일반적인 빌드 산출물로 취급해 삭제하거나 덮어쓰지 마세요. 빌드 도구 없이 ESM JavaScript로 실행합니다.
- `story-quality/src/`는 TypeScript 원본입니다. 수정 후 빌드하여 `story-quality/dist/`와 프런트엔드의 `dist/story-quality/` 사본을 동기화합니다. 루트 `npm run build`가 이 작업을 합니다.
- `server/cloud-api.js`는 계정별 D1/R2 보관 API입니다. `cloud-runtime/`는 Vinext/Cloudflare Worker 런타임이며 `db/schema.ts`와 `drizzle/`에 스키마·마이그레이션이 있습니다.
- `cloud-runtime/public/`, `cloud-runtime/dist/`, `.wrangler/`, `node_modules/`는 생성물이므로 직접 수정하지 않습니다.

## 검증

Node.js 22.13 이상을 사용하세요. 컴파일된 패키지가 포함되어 있어 아래 테스트는 의존성 설치 없이 실행할 수 있습니다.

```bash
npm test
npm run test:quality
```

전체 빌드에는 `npm --prefix cloud-runtime ci`가 먼저 필요합니다. 이후 루트에서 `npm run build`를 실행합니다. 상세한 로컬 실행·DB 준비 명령은 시작 문서에 있습니다.

## 유지할 동작

- 이미지 엔진 World와 이야기 세계 카드 100종은 별개입니다. 계절·시간 분위기를 적용하면서 승인 배경의 구조, 캐릭터 시트, 화풍 참조, 시드와 책별 설정 스냅샷을 보존합니다.
- 새 줄거리의 `plotContract`에는 원인·시도·결과·다음 결정과 인물/소품 상태가 연결됩니다. 최종 쪽의 일관성 검사 결과는 검수한 내용 지문에 묶여야 합니다. 오래된 통과 결과로 그림을 생성하면 안 됩니다.
- FULL AUTO 상세 창을 닫는 것은 중지가 아닙니다. 명시적 중지·부모 잠금·브라우저 종료에서만 실행을 중단하며 유료 응답과 진행 상태를 보관합니다. 재개 시 완료 호출을 다시 결제하지 않게 하세요.
- `storyDate`와 세계/계절/시간 설정은 제작 시점에 고정합니다. 재접속 날짜로 계절을 다시 계산하지 않습니다.
- 키는 브라우저 PIN 기반 AES-GCM 보관함 또는 별도 프록시 환경변수에서만 읽습니다. 라이브러리·프롬프트·로그·백업·소스에 키를 넣지 않습니다. 추적 ID `key_...`는 OpenAI API 비밀 키가 아닙니다.
- 서버는 Sites가 검증해 전달한 인증 헤더를 신뢰합니다. 다른 호스팅에 옮길 때 클라이언트가 보낸 같은 이름의 헤더를 인증으로 쓰지 마세요. 출처·계정 일치·CAS 버전 검사는 유지하세요.
- 새 DB 변경은 Drizzle 마이그레이션으로 추가합니다. 이미 적용한 SQL을 덮어쓰거나 요청 처리 중 DDL을 실행하지 않습니다.
- API 오류 때 샘플 그림·고정 이야기로 자동 대체하지 않습니다. 모의 테스트 통과와 실제 유료 모델의 글/그림 품질 평가는 구분합니다.
- 유료 `distill`, `eval`, 코치, 파인튜닝 실행은 사용자가 요청한 범위에서만 합니다. `topics:gen`과 `distill:estimate`는 모델 호출 없이 실행됩니다. 대량 증류는 아직 실행하지 않았습니다.

## 변경 전달

이 압축본은 Git 자격 증명·사용자 DB·실제 API 키를 포함하지 않습니다. 압축을 푼 뒤 자체 Git 저장소를 시작하고 기능별로 커밋하면 후속 통합이 쉽습니다. 기존 `.openai/hosting.json`의 프로젝트 ID는 현재 사이트의 식별자입니다. 소스 수정만으로 운영 사이트에 자동 배포되지 않으며 배포 권한과 호스팅 연결은 별도입니다.
